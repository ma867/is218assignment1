const squareroot = require('./squareroot');

test('squareroot  4 is equal to 2', () => {
    expect(squareroot(4)).toBe(2);
});