function squareroot(a) {
    return Math.sqrt(a);
}
module.exports = squareroot;