const square = require('./square');

test('square 2 squared is equal to 4', () => {
    expect(square(2)).toBe(4);
});