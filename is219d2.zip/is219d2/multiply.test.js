const multiply = require('./multiply');

test('multiplied 2 multiplied by  2 to equal 4', () => {
    expect(multiply(2, 2)).toBe(4);
});