const sum = require('./sum');
a = 1;
b = 3;
c = sum(a,b);


console.log(c);
